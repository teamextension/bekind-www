
CREATE TABLE xtr_ws_jobs_log (
  log_date DATE,
  log_level VARCHAR2(10),
  name VARCHAR2(100),
  message VARCHAR2(4000)
);
