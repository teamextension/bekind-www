-- DROP TABLE xtr_erp_intf_log;
-- DROP VIEW xtr_erp_intf_sbd_material_lot;
-- DROP TABLE xtr_erp_intf_sbd_lot;
-- DROP TABLE xtr_erp_intf_sbd_material;
-- DROP TABLE xtr_erp_intf_stage_material;
-- DROP TRIGGER xtr_erp_intf_material_trigger;
-- DROP TABLE xtr_erp_intf_material;

--
-- TrackWise external table
--
CREATE TABLE xtr_erp_intf_material (
  site_code VARCHAR(10) NOT NULL,
  code VARCHAR(30) NOT NULL,
  description VARCHAR(80) NOT NULL,
  type CHAR(1) NOT NULL,
  lot_number VARCHAR(20) NOT NULL,
  modified_on DATE DEFAULT SYSDATE NOT NULL
);

CREATE INDEX xtr_erp_intf_mat_site_code_idx ON xtr_erp_intf_material(site_code);
CREATE INDEX xtr_erp_intf_mat_code_idx ON xtr_erp_intf_material(code);

CREATE OR REPLACE TRIGGER xtr_erp_intf_material_trigger
BEFORE INSERT OR UPDATE ON xtr_erp_intf_material FOR EACH ROW
BEGIN
  :new.modified_on := SYSDATE;
END;
/

--
-- ERP Interface staging table
--
CREATE TABLE xtr_erp_intf_stage_material (
  site_code VARCHAR(10) NOT NULL,
  code VARCHAR(30) NOT NULL,
  description VARCHAR(80) NOT NULL,
  type CHAR(1) NOT NULL,
  lot_number VARCHAR(20) NOT NULL
);

CREATE INDEX xtr_erp_intf_sta_site_code_idx ON xtr_erp_intf_stage_material(site_code);
CREATE INDEX xtr_erp_intf_stage_code_idx ON xtr_erp_intf_stage_material(code);

--
-- ERP Interface staging table for SAP ByDesign materials
--
CREATE TABLE xtr_erp_intf_sbd_material (
  site_code VARCHAR(10) NOT NULL,
  code VARCHAR(30) NOT NULL,
  description VARCHAR(80) NOT NULL,
  type CHAR(1) NOT NULL,
  last_change_date DATE
);

CREATE INDEX xtr_erp_intf_sbd_mat_code_idx ON xtr_erp_intf_sbd_material(code);

--
-- ERP Interface staging table for SAP ByDesign lots
--
CREATE TABLE xtr_erp_intf_sbd_lot (
  code VARCHAR(30) NOT NULL,
  lot_number VARCHAR(20) NOT NULL,
  last_change_date DATE
);

CREATE INDEX xtr_erp_intf_sbd_lot_code_idx ON xtr_erp_intf_sbd_lot(code);

--
-- View joining xtr_erp_intf_sbd_material and xtr_erp_intf_sbd_lot
--
CREATE OR REPLACE VIEW xtr_erp_intf_sbd_material_lot AS
SELECT m.site_code, m.code, m.description, m.type, l.lot_number, (CASE WHEN m.last_change_date > l.last_change_date THEN m.last_change_date ELSE l.last_change_date END) last_change_date
FROM xtr_erp_intf_sbd_material m JOIN xtr_erp_intf_sbd_lot l ON m.code=l.code;

--
-- Database log
--
CREATE TABLE xtr_erp_intf_log (
  log_date DATE,
  log_level VARCHAR2(10),
  name VARCHAR2(100),
  message VARCHAR2(4000)
);
