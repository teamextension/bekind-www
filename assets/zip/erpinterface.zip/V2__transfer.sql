-- DROP PROCEDURE xtr_erp_intf_transfer;
-- DROP PROCEDURE xtr_erp_intf_sbd_incr_transfer;
-- DROP PROCEDURE xtr_erp_intf_sbd_full_transfer;
-- DROP PROCEDURE xtr_erp_intf_stage_transfer;

--
-- Stored procedure that transfers staging data to the TrackWise external table. From xtr_erp_intf_stage_material
-- to xtr_erp_intf_material.
--
CREATE OR REPLACE PROCEDURE xtr_erp_intf_stage_transfer (
  out_insert_count OUT NUMBER,
  out_update_count OUT NUMBER)
AS
  CURSOR stage_material_cursor IS
  SELECT * FROM xtr_erp_intf_stage_material s WHERE NOT EXISTS (
    SELECT * FROM xtr_erp_intf_material m
    WHERE m.site_code=s.site_code AND m.code=s.code AND m.description=s.description AND m.lot_number=s.lot_number
  );
  stage_material xtr_erp_intf_stage_material%ROWTYPE;

  material_count NUMBER;
  insert_count NUMBER := 0;
  update_count NUMBER := 0;

BEGIN
  FOR stage_material IN stage_material_cursor
  LOOP
    BEGIN
      SELECT COUNT(*) INTO material_count FROM xtr_erp_intf_material
        WHERE site_code=stage_material.site_code AND code=stage_material.code AND lot_number=stage_material.lot_number;

      IF material_count > 0 THEN
          UPDATE xtr_erp_intf_material SET description=stage_material.description
            WHERE site_code=stage_material.site_code AND code=stage_material.code AND lot_number=stage_material.lot_number;
          update_count := update_count + 1;
      ELSE
        INSERT INTO xtr_erp_intf_material(site_code, code, description, type, lot_number)
          VALUES(stage_material.site_code, stage_material.code, stage_material.description, stage_material.type, stage_material.lot_number);
        insert_count := insert_count + 1;
      END IF;
    END;
  END LOOP;

  out_insert_count := insert_count;
  out_update_count := update_count;
END xtr_erp_intf_stage_transfer;
/

--
-- Stored procedure that transfers SAP ByDesign staging data to the TrackWise external table. From
-- xtr_erp_intf_sbd_material_lot to xtr_erp_intf_material. Called during full loads.
--
CREATE OR REPLACE PROCEDURE xtr_erp_intf_sbd_full_transfer (
  out_insert_count OUT NUMBER,
  out_update_count OUT NUMBER)
AS
  CURSOR sbd_material_cursor IS
  SELECT * FROM xtr_erp_intf_sbd_material_lot s
  WHERE NOT EXISTS (
    SELECT * FROM xtr_erp_intf_material m
    WHERE m.site_code='BRB' AND m.code=s.code AND m.description=s.description AND m.lot_number=s.lot_number
  );
  sbd_material xtr_erp_intf_sbd_material_lot%ROWTYPE;

  material_count NUMBER;
  insert_count NUMBER := 0;
  update_count NUMBER := 0;

BEGIN
  FOR sbd_material IN sbd_material_cursor
  LOOP
    BEGIN
      SELECT COUNT(*) INTO material_count FROM xtr_erp_intf_material
        WHERE site_code=sbd_material.site_code AND code=sbd_material.code AND lot_number=sbd_material.lot_number;

      IF material_count > 0 THEN
          UPDATE xtr_erp_intf_material SET description=sbd_material.description
            WHERE site_code=sbd_material.site_code AND code=sbd_material.code AND lot_number=sbd_material.lot_number;
          update_count := update_count + 1;
      ELSE
        INSERT INTO xtr_erp_intf_material(site_code, code, description, type, lot_number)
          VALUES(sbd_material.site_code, sbd_material.code, sbd_material.description, sbd_material.type, sbd_material.lot_number);
        insert_count := insert_count + 1;
      END IF;
    END;
  END LOOP;

  out_insert_count := insert_count;
  out_update_count := update_count;
END xtr_erp_intf_sbd_full_transfer;
/

--
-- Stored procedure that transfers SAP ByDesign staging data to the TrackWise external table. From
-- xtr_erp_intf_sbd_material_lot to xtr_erp_intf_material. Called during incremental loads.
--
CREATE OR REPLACE PROCEDURE xtr_erp_intf_sbd_incr_transfer (
  in_incremental_days IN NUMBER,
  out_insert_count OUT NUMBER,
  out_update_count OUT NUMBER)
AS
  CURSOR sbd_material_cursor IS
  SELECT * FROM xtr_erp_intf_sbd_material_lot s
  WHERE TRUNC(last_change_date) > (TRUNC(SYSDATE) - in_incremental_days) AND NOT EXISTS (
    SELECT * FROM xtr_erp_intf_material m
    WHERE m.site_code='BRB' AND m.code=s.code AND m.description=s.description AND m.lot_number=s.lot_number
  );

  sbd_material xtr_erp_intf_sbd_material_lot%ROWTYPE;

  material_count NUMBER;
  insert_count NUMBER := 0;
  update_count NUMBER := 0;

BEGIN
  FOR sbd_material IN sbd_material_cursor
  LOOP
    BEGIN
      SELECT COUNT(*) INTO material_count FROM xtr_erp_intf_material
        WHERE site_code=sbd_material.site_code AND code=sbd_material.code AND lot_number=sbd_material.lot_number;

      IF material_count > 0 THEN
          UPDATE xtr_erp_intf_material SET description=sbd_material.description
            WHERE site_code=sbd_material.site_code AND code=sbd_material.code AND lot_number=sbd_material.lot_number;
          update_count := update_count + 1;
      ELSE
        INSERT INTO xtr_erp_intf_material(site_code, code, description, type, lot_number)
          VALUES(sbd_material.site_code, sbd_material.code, sbd_material.description, sbd_material.type, sbd_material.lot_number);
        insert_count := insert_count + 1;
      END IF;
    END;
  END LOOP;

  out_insert_count := insert_count;
  out_update_count := update_count;
END xtr_erp_intf_sbd_incr_transfer;
/

--
-- This is the primary stored procedure, called by the ERP Interface Java code. It first calls
-- xtr_erp_intf_stage_transfer, then calls either xtr_erp_intf_sbd_full_transfer or xtr_erp_intf_sbd_incr_transfer,
-- depending on if this is a full or incremental load.
--
CREATE OR REPLACE PROCEDURE xtr_erp_intf_transfer (
  in_incremental_days IN NUMBER,
  out_insert_count OUT NUMBER,
  out_update_count OUT NUMBER,
  out_status_code OUT NUMBER,
  out_message OUT VARCHAR2)
AS
  stage_insert_count NUMBER;
  stage_update_count NUMBER;

  sbd_insert_count NUMBER;
  sbd_update_count NUMBER;

  start_time NUMBER;
  message VARCHAR2(32767);
BEGIN
  start_time := dbms_utility.get_time;

  xtr_erp_intf_stage_transfer(stage_insert_count, stage_update_count);
  dbms_output.put_line('stage_insert_count=' || stage_insert_count || ' stage_update_count=' || stage_update_count);

  IF in_incremental_days = -1 THEN
    xtr_erp_intf_sbd_full_transfer(sbd_insert_count, sbd_update_count);
    dbms_output.put_line('sbd_insert_count=' || sbd_insert_count || ' sbd_update_count=' || sbd_update_count);
  ELSE
    xtr_erp_intf_sbd_incr_transfer(in_incremental_days, sbd_insert_count, sbd_update_count);
    dbms_output.put_line('in_incremental_days=' || in_incremental_days || ' sbd_insert_count=' || sbd_insert_count || ' sbd_update_count=' || sbd_update_count);
  END IF;

  out_insert_count := stage_insert_count + sbd_insert_count;
  out_update_count := stage_update_count + sbd_update_count;

  message := 'inserted=' || out_insert_count || ' updated=' || out_update_count || ' seconds=' || ((dbms_utility.get_time - start_time)/100) || ' message=' || out_message;
  -- INSERT INTO xtr_erp_intf_log (log_date, log_level, name, message) VALUES (SYSDATE, 'INFO', 'xtr_erp_intf_transfer', SUBSTR(message, 1, 4000));

  -- truncate tables
  EXECUTE IMMEDIATE 'TRUNCATE TABLE xtr_erp_intf_stage_material';

  -- to support SAP ByDesign incremental load, do NOT truncate SAP ByDesign staging tables
  -- EXECUTE IMMEDIATE 'TRUNCATE TABLE xtr_erp_intf_sbd_lot';
  -- EXECUTE IMMEDIATE 'TRUNCATE TABLE xtr_erp_intf_sbd_material';

  out_message := 'OK';
  out_status_code := 0;

EXCEPTION
  WHEN OTHERS THEN
    message := SQLERRM;
    -- INSERT INTO xtr_erp_intf_log (log_date, log_level, name, message) VALUES (SYSDATE, 'ERROR', 'xtr_erp_intf_transfer', SUBSTR(message, 1, 4000));

    out_message := message;
    out_status_code := 1;

END xtr_erp_intf_transfer;
/
