-- DROP VIEW xtr_erp_product_lot_number;
-- DROP VIEW xtr_erp_product_desc;
-- DROP VIEW xtr_erp_product_code;
-- DROP VIEW xtr_erp_product_site_code;
-- DROP VIEW xtr_erp_material_lot_number;
-- DROP VIEW xtr_erp_material_desc;
-- DROP VIEW xtr_erp_material_code;
-- DROP VIEW xtr_erp_material_site_code;

--
-- TrackWise external view for Material Site
--
CREATE OR REPLACE VIEW xtr_erp_material_site_code (id, site_code) AS
SELECT DISTINCT site_code id, site_code FROM xtr_erp_intf_material WHERE type='C' ORDER BY id;

--
-- TrackWise external view for Material Code #
--
CREATE OR REPLACE VIEW xtr_erp_material_code (site_code, id, code) AS
SELECT DISTINCT site_code, site_code||code id, code FROM xtr_erp_intf_material WHERE type='C' ORDER BY id;

--
-- TrackWise external view for Material Description
--
CREATE OR REPLACE VIEW xtr_erp_material_desc (id, description) AS
SELECT DISTINCT site_code||code id, description FROM xtr_erp_intf_material WHERE type='C' ORDER BY id, description;

--
-- TrackWise external view for Local Material Lot #
--
CREATE OR REPLACE VIEW xtr_erp_material_lot_number (parent_id, id, lot_number) AS
SELECT DISTINCT site_code||code parent_id, site_code||code||lot_number id, lot_number FROM xtr_erp_intf_material WHERE type='C' ORDER BY id, lot_number;

--
-- TrackWise external view for Product Site
--
CREATE OR REPLACE VIEW xtr_erp_product_site_code (id, site_code) AS
SELECT DISTINCT site_code id, site_code FROM xtr_erp_intf_material WHERE type='F' ORDER BY id;

--
-- TrackWise external view for Product Code #
--
CREATE OR REPLACE VIEW xtr_erp_product_code (site_code, id, code) AS
SELECT DISTINCT site_code, site_code||code id, code FROM xtr_erp_intf_material WHERE type='F' ORDER BY id, code;

--
-- TrackWise external view for Product Description
--
CREATE OR REPLACE VIEW xtr_erp_product_desc (id, description) AS
SELECT DISTINCT site_code||code id, description FROM xtr_erp_intf_material WHERE type='F' ORDER BY id, description;

--
-- TrackWise external view for Local Product Lot #
--
CREATE OR REPLACE VIEW xtr_erp_product_lot_number (parent_id, id, lot_number) AS
SELECT DISTINCT site_code||code parent_id, site_code||code||lot_number id, lot_number FROM xtr_erp_intf_material WHERE type='F' ORDER BY id, lot_number;
